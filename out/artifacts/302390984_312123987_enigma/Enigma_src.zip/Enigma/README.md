Enigma Console Application by Omer Gabay 
ID 302390984 
EMAIL omer.gabay@yahoo.com 

To start the application run the script 'enigma.bat'
You will be presented with a menu, to select an option from the menu input
the option number and press Enter. 

Before starting to work with the Enigma, 
you need to choose option 1 to import enigma configuration file in XML format. 
Then choose option 3 or 4 to set up the machine.

BONUS - CREATING AND LOADING MACHINE BACKUPS
Loading Backups - 
You will be asked to enter the absolute(full) path of your enigma backup.
Your backup file should end with .buk extension. 
After loading backup you can continue using the machine normally.   
Creating Backups - 
First you need to choose the folder path, 
then you'll be asked for the name of the backup file.
For example if you named your file "myenigma" a file called "myenigma.buk" will be created. 
Note that you can create backups only after you loaded enigma xml file and finished setting up the machine.




