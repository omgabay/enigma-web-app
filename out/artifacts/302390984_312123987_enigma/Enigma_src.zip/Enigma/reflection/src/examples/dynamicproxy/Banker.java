package examples.dynamicproxy;

public interface Banker {

    int getMoney();

    void setMoney(int money);
}
