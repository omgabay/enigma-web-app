package exceptions;

public class ReflectorNotFound  extends EnigmaException{
    public ReflectorNotFound(){super("Error in Setup - Reflector was not found!");}
}
