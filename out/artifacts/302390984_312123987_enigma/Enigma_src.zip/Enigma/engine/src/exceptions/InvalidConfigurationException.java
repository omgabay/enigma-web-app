package exceptions;

public class InvalidConfigurationException extends EnigmaException{

    public InvalidConfigurationException(String message){super(message);}
}
