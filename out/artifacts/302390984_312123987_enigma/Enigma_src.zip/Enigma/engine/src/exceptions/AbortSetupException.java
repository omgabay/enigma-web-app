package exceptions;

public class AbortSetupException extends RuntimeException{
    public AbortSetupException(){
        super();
    }
}
