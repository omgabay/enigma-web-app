package exceptions;

public class WrongFileFormatException extends EnigmaException{
    public WrongFileFormatException(String message){
        super(message);
    }
}
