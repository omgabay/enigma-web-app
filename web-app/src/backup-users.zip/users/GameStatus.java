package users;

public enum GameStatus {REGISTRATION, WAITING_FOR_TEAMS, RUNNING, DONE}
