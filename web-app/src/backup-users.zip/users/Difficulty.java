package users;

public enum Difficulty {EASY, MEDIUM, HARD, INSANE}
